#!/bin/sh

# Install scripts 
cp init.d/* /etc/init.d

# Install lsmonitor daemon
update-rc.d -f lsmonitor remove
update-rc.d lsmonitor defaults 99 00

