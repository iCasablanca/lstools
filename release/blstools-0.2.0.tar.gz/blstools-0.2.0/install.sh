#!/bin/sh

# Check running user
USERID=$(id -u)
if [ $USERID -ne 0 ] ; then
	echo 'This program must be run as root'
	exit 1
fi

# Install scripts 
cp init.d/* /etc/init.d
cp default/* /etc/default

# Install lsmonitor daemon
update-rc.d -f lsmonitor remove
update-rc.d lsmonitor defaults 99 00

